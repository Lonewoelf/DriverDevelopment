#!/bin/bash

echo "writeTest" > /dev/RW_0

cat /dev/RW_0