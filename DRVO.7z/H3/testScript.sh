#!/bin/bash

echo "writeTest" > /dev/myReadWrite

cat /dev/myReadWrite